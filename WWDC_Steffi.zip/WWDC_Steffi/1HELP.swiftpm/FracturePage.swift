//
//  FracturePage.swift
//  wwdc
//
//  Created by Steffi Estherianti on 08/04/23.
//

import SwiftUI

struct FracturePage: View {
    
    @State var index = 0
    
    var body: some View {
        
        NavigationView() {
            ZStack{
                Color(.white)
                    .overlay(
                        RoundedRectangle(cornerRadius: 30)
                            .fill(Color(red: 191/255, green: 62/255, blue: 62/255))
                            .ignoresSafeArea(.all))
                    .padding(30)
                
                    VStack(alignment: .leading){
                        NavigationLink (destination: homepage().navigationBarBackButtonHidden(true)){
                                Image("Image 2")
                                    .resizable()
                                    .frame(width: 50, height: 50)
                                    .padding(EdgeInsets(top: 0, leading: 40, bottom: 0, trailing: 0))
                        }
                        
                        Text("FRACTURE")
                            .font(.system(size: 35, weight: .bold))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity, alignment: .center)
                        Text("First Aid for Fracture")
                            .font(.system(size: 35, weight: .bold))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity, alignment: .center)
                            .padding()
                        
                        HStack {
                            Spacer()
                            TabView(selection: $index) {
                                VStack(alignment: .leading){
                                    HStack{
                                        Image("F1")
                                            .resizable()
                                            .frame(width: 250, height: 250)
                                        
                                        Text("Stop bleeding, especially in the case of open fracture where the skin is torn, by wrapping the wound with a sterile bandage or a clean cloth.")
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                            .padding(.leading, 20)
                                            .font(.system(size: 22, weight:.bold))
                                            .frame(width: 450)
                                            .foregroundColor(.white)
                                            .fixedSize(horizontal: true, vertical: false)
                                        }
                                    
                                    HStack{
                                        Image("F2")
                                            .resizable()
                                            .frame(width: 250, height: 250)
            
                                        Text("Avoid moving the affected area; any movement can result in serious complications—especially in the case of neck and back fractures.")
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                            .padding(.leading, 20)
                                            .font(.system(size: 22, weight:.bold))
                                            .frame(width: 450)
                                            .foregroundColor(.white)
                                            .fixedSize(horizontal: true, vertical: false)
                                        }
                                    
                                    HStack{
                                        Image("F3")
                                            .resizable()
                                            .frame(width: 250, height: 250)
                        
                                        Text("Cool the affected area by applying and ice pack or ice cubes wrapped in a clean cloth.")
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                            .padding(.leading, 20)
                                            .font(.system(size: 22, weight:.bold))
                                            .frame(width: 450)
                                            .foregroundColor(.white)
                                            .fixedSize(horizontal: true, vertical: false)
                                        }
                                }
                                .frame(width: 700)
                                .tag(0)
                                
                                
                                VStack(alignment: .leading){
                                    
                                    HStack{
                                        Image("F4")
                                            .resizable()
                                            .frame(width: 250, height: 250)
                                        
                                        Text("Treat the patient's shock: help them get into a comfortable position, encourage them to rest, and reassure them. Cover them with a blanket or clothing to keep them warm.")
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                            .padding(.leading, 20)
                                            .font(.system(size: 22, weight:.bold))
                                            .frame(width: 450)
                                            .foregroundColor(.white)
                                            .fixedSize(horizontal: true, vertical: false)
                                        }
                                    
                                    HStack{
                                        Image("F5")
                                            .resizable()
                                            .frame(width: 250, height: 250)
            
                                        Text("Call the ambulance, and help the patient get to the emergency department for examination and treatment.​​")
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                            .padding(.leading, 20)
                                            .font(.system(size: 22, weight:.bold))
                                            .frame(width: 450)
                                            .foregroundColor(.white)
                                            .fixedSize(horizontal: true, vertical: false)
                                        }
                                
                                }
                                .frame(width: 700)
                                .tag(1)

                            }
                            .tabViewStyle(PageTabViewStyle())
                        .frame(width: 750, height: 850)
                            Spacer()
                        }
                    }
            }
        }
        .navigationViewStyle(StackNavigationViewStyle())
        }
    }
struct FracturePage_Previews: PreviewProvider {
    static var previews: some View {
        FracturePage()
    }
}
