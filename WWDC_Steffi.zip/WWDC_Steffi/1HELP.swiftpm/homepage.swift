//
//  homepage.swift
//  wwdc
//
//  Created by Steffi Estherianti on 08/04/23.
//

import SwiftUI

struct homepage: View {
    
    //    @State private var CPRHowTo = false
    
    var body: some View {
        NavigationView{
            
            VStack{
                Image("1HELP")
                    .imageScale(.small)
                    .padding()
                    .padding()
                VStack{
                    NavigationLink (destination: CprPage().navigationBarBackButtonHidden(true)){
                        Capsule()
                            .fill(Color(red: 192/255, green: 62/255, blue: 62/255))
                            .frame(width: 250, height: 80)
                            .overlay(
                                Text("CPR")
                                    .font(.system(size: 24, weight:.bold))
                                    .multilineTextAlignment(.center)
                                    .foregroundColor(.white))
                    }
                    .padding()
                    NavigationLink (destination: FracturePage().navigationBarBackButtonHidden(true)){
                        Capsule()
                            .fill(Color(red: 192/255, green: 62/255, blue: 62/255))
                            .frame(width: 250, height: 80)
                            .overlay(
                                Text("FRACTURE")
                                    .font(.system(size: 24, weight:.bold))
                                    .foregroundColor(.white))
                    }
                    .padding()
                    NavigationLink (destination:
                        BitesStingsPage().navigationBarBackButtonHidden(true)){
                        Capsule()
                            .fill(Color(red: 192/255, green: 62/255, blue: 62/255))
                            .frame(width: 250, height: 80)
                            .overlay(
                                Text("SNAKE BITES")
                                    .font(.system(size: 24, weight:.bold))
                                    .foregroundColor(.white))
                    }
                    .padding()
                }
            }
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
        
        struct homepage_Previews: PreviewProvider {
            static var previews: some View {
                homepage()
            }
        }
    }

