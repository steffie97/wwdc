//
//  BitesStingsPage.swift
//  wwdc
//
//  Created by Steffi Estherianti on 17/04/23.
//

import SwiftUI

struct BitesStingsPage: View {
    
    @State var index = 0
    
    var body: some View {
        
        NavigationView() {
            ZStack{
                Color(.white)
                    .overlay(
                        RoundedRectangle(cornerRadius: 30)
                            .fill(Color(red: 191/255, green: 62/255, blue: 62/255))
                            .ignoresSafeArea(.all))
                    .padding(30)
                
                    VStack(alignment: .leading){
                        NavigationLink (destination: homepage().navigationBarBackButtonHidden(true)){
                                Image("Image 2")
                                    .resizable()
                                    .frame(width: 50, height: 50)
                                    .padding(EdgeInsets(top: 0, leading: 40, bottom: 0, trailing: 0))
                        }
                        
                        Text("First Aid")
                            .font(.system(size: 25, weight: .bold))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity, alignment: .center)
                        
                        HStack {
                            Spacer()
                            TabView(selection: $index) {
                                VStack(alignment: .leading){
                                    Text("Snake Bites")
                                        .font(.system(size: 30, weight: .bold))
                                        .foregroundColor(.white)
                                        .frame(maxWidth: .infinity, alignment: .center)
                                    HStack{
                                        Image("B1")
                                            .resizable()
                                            .frame(width: 150, height: 150)
                                        
                                        Text("Call an ambulance straight away.")
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                            .padding(.leading, 20)
                                            .font(.system(size: 20, weight:.bold))
                                            .frame(width: 450)
                                            .foregroundColor(.white)
                                            .fixedSize(horizontal: true, vertical: false)
                                        }
                                    
                                    HStack{
                                        Image("B2")
                                            .resizable()
                                            .frame(width: 150, height: 150)
            
                                        Text("Keep the bitten person still and calm, as this can help slow down the spread of venom in the body. \nWash the bite area with soap and water immediately.")
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                            .padding(.leading, 20)
                                            .font(.system(size: 20, weight:.bold))
                                            .frame(width: 450)
                                            .foregroundColor(.white)
                                            .fixedSize(horizontal: true, vertical: false)
                                        }
                                    
                                    HStack{
                                        Image("B3")
                                            .resizable()
                                            .frame(width: 150, height: 150)
                        
                                        Text("Keep the affected area below the heart level to reduce the flow of venom.")
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                            .padding(.leading, 20)
                                            .font(.system(size: 20, weight:.bold))
                                            .frame(width: 450)
                                            .foregroundColor(.white)
                                            .fixedSize(horizontal: true, vertical: false)
                                        }
                                    HStack{
                                        Image("B4")
                                            .resizable()
                                            .frame(width: 150, height: 150)
                                    
                                        Text("Treat the patient's shock: help them get into a comfortable position, encourage them to rest, and reassure them. Cover them with a blanket or clothing to keep them warm.")
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                            .padding(.leading, 20)
                                            .font(.system(size: 20, weight:.bold))
                                            .frame(width: 450)
                                            .foregroundColor(.white)
                                            .fixedSize(horizontal: true, vertical: false)
                                        }
                                
                                HStack{
                                    Image("B5")
                                        .resizable()
                                        .frame(width: 150, height: 150)
        
                                    Text("1. Avoid touching or pressing the affected area.\n2. Avoid injuring the affected area or sucking poison from it.\n3. Avoid applying ice or soaking the wound in a water.\n4. Avoid drinking caffeinated beverages.")
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                        .padding(.leading, 20)
                                        .font(.system(size: 20, weight:.bold))
                                        .frame(width: 450)
                                        .foregroundColor(.white)
                                        .fixedSize(horizontal: true, vertical: false)
                                    }
                                }
                                .frame(width: 700)
                                .tag(0)
//                                .Spacer()

                            }
                            .tabViewStyle(PageTabViewStyle())
                        .frame(width: 750, height: 870)
                            Spacer()
                        }
                    }
            }
        }
        .navigationViewStyle(StackNavigationViewStyle())
        }
    }

struct BitesStingsPage_Previews: PreviewProvider {
    static var previews: some View {
        BitesStingsPage()
    }
}
