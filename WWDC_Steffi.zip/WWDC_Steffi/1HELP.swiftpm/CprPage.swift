//
//  CprPage.swift
//  wwdc
//
//  Created by Steffi Estherianti on 08/04/23.
//

import SwiftUI
import AVKit

class SoundManager {
    var player: AVAudioPlayer?
    
    func playSound(){
        
        guard let url = Bundle.main.url(forResource: "metro", withExtension: "mp3")
        else{
            return
        }
        
        do{
            player = try AVAudioPlayer(contentsOf: url)
            player?.currentTime = 6
            player?.play()
        } catch let error{
            print(error.localizedDescription)
        }
        
    }
    func stopAll() {
        player?.stop()
    }
}

struct CprPage: View {
    @State var index = 0
    
    @State var soundManager: SoundManager = SoundManager()
    @State var animationAmount = 0.8
    @State var isPlaying = false
    
    @State var countDownTimer = 60
    @State var timerRunning = false
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    
    var body: some View {
        
        NavigationView{
            
            ZStack{
                Color(.white)
                    .overlay(
                        RoundedRectangle(cornerRadius: 30)
                            .fill(Color(red: 191/255, green: 62/255, blue: 62/255))
                            .ignoresSafeArea(.all))
                    .padding(30)
                
                    VStack(alignment: .leading){
                        NavigationLink (destination: homepage().navigationBarBackButtonHidden(true)){
                                Image("Image 2")
                                    .resizable()
                                    .frame(width: 50, height: 50)
                                    .padding(EdgeInsets(top: 0, leading: 40, bottom: 0, trailing: 0))
                        }
                        
                        Text("CPR")
                            .font(.system(size: 35, weight: .bold))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity, alignment: .center)
                        Text("How to do CPR")
                            .font(.system(size: 35, weight: .bold))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity, alignment: .center)
                            .padding()
                        
                        HStack {
                            Spacer()
                            TabView(selection: $index) {
                                VStack(alignment: .leading){
                                    HStack{
                                        Image("1")
                                            .resizable()
                                            .frame(width: 250, height: 250)
                                        
                                        Text("Call 1-1-2, or tell someone to do so.")
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                            .padding(.leading, 20)
                                            .font(.system(size: 22, weight:.bold))
                                            .frame(width: 450)
                                            .foregroundColor(.white)
                                            .fixedSize(horizontal: true, vertical: false)
                                        }
                                    
                                    HStack{
                                        Image("2")
                                            .resizable()
                                            .frame(width: 250, height: 250)
            
                                        Text("Check for responsiveness, breathing, and bleed ingusing shout-tap-shout.")
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                            .padding(.leading, 20)
                                            .font(.system(size: 22, weight:.bold))
                                            .frame(width: 450)
                                            .foregroundColor(.white)
                                            .fixedSize(horizontal: true, vertical: false)
                                            }
                                    
                                    HStack{
                                        Image("3")
                                            .resizable()
                                            .frame(width: 250, height: 250)
                        
                                        Text("Kneel beside the person. Place the person on their back on a firm, flat surface.")
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                            .padding(.leading, 20)
                                            .font(.system(size: 22, weight:.bold))
                                            .frame(width: 450)
                                            .foregroundColor(.white)
                                            .fixedSize(horizontal: true, vertical: false)
                                    }
                                }
                                .frame(width: 700)
                                .tag(0)
                                
                                
                                VStack(alignment: .leading){
                                    
                                    HStack{
                                        Image("4")
                                            .resizable()
                                            .frame(width: 250, height: 250)
                                        VStack{
                                            Text("Give 2 breaths")
                                                .frame(maxWidth: .infinity, alignment: .leading)
                                                .padding(.leading, 20)
                                                .font(.system(size: 22, weight:.bold))
                                                .frame(width: 450)
                                                .foregroundColor(.white)
                                                .fixedSize(horizontal: true, vertical: false)
                                            Text("a. Open the airway to a past-neutral position using the head-tilt/chin-lift technique \n b. Pinch the nose shut, take a normal breath, and make complete seal over the person’s mouth with your mouth. \n c. Ensure each breath lasts about 1 second and makes the chest rise; allow air to exit before giving the next breath.")
                                                .frame(maxWidth: .infinity, alignment: .leading)
                                                .padding(.leading, 20)
                                                .font(.system(size: 20, weight:.bold))
                                                .frame(width: 450)
                                                .foregroundColor(.white)
                                                .fixedSize(horizontal: true, vertical: false)
                                            }
                                        }
                                    
                                    HStack{
                                        Image("5")
                                            .resizable()
                                            .frame(width: 250, height: 250)
                                        VStack{
                                            Text("Give 30 chest compressions")
                                                .frame(maxWidth: .infinity, alignment: .leading)
                                                .padding(.leading, 20)
                                                .font(.system(size: 22, weight:.bold))
                                                .frame(width: 450)
                                                .foregroundColor(.white)
                                                .fixedSize(horizontal: true, vertical: false)
                                            Text("a. Hand position: Two hands centered on the chest \n b. Body position: Shoulders directly over hands; elbows locked \n c. Depth: At least 2 inches \n d. Rate: 100 to 120 per minute \n e. Allow chest to return to normal position after each compression.")
                                                .frame(maxWidth: .infinity, alignment: .leading)
                                                .padding(.leading, 20)
                                                .font(.system(size: 20, weight:.bold))
                                                .frame(width: 450)
                                                .foregroundColor(.white)
                                                .fixedSize(horizontal: true, vertical: false)
                                            }
                                        }
                                    
                                    HStack{
                                        Image("6")
                                            .resizable()
                                            .frame(width: 250, height: 250)
                        
                                        Text("If the 1st breath does not cause the chest to rise, retilt the head and ensure a proper seal before giving the 2nd breath If the 2nd breath does not make the chest rise, an object may be blocking the airway")
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                            .padding(.leading, 20)
                                            .font(.system(size: 22, weight:.bold))
                                            .frame(width: 450)
                                            .foregroundColor(.white)
                                            .fixedSize(horizontal: true, vertical: false)
                                    }
                                }
                                .frame(width: 700)
                                .tag(1)
                                
                                VStack{
                                    
                                    Text("\(countDownTimer)")
                                            .onReceive(timer) { _ in
                                                if countDownTimer > 0 && timerRunning{
                                                    countDownTimer -= 1
                                                } else {
                                                    timerRunning = false
                                                }
                                            }
                                            .font(.system(size: 50, weight: .bold))
                                            .foregroundColor(.white)
//                                            .opacity(0.80)
                                    if isPlaying {
                                        Button{
                                            isPlaying.toggle()
                                            timerRunning.toggle()
                                            soundManager.stopAll()
                                        } label: {
                                            Image("Image 1")
                                                .resizable()
                                                .frame(width: 450, height: 450)
                                                .scaleEffect(animationAmount)
                                                .opacity(2 - animationAmount)
                                                .animation(
                                                    .easeIn(duration: 0.59)
                                                    .repeatForever(autoreverses: false), value:animationAmount)
                                                .onAppear{
                                                    animationAmount = 1
                                                }
                                        }
                                    }
                                    else {
                                        Button{
                                            isPlaying.toggle()
                                            timerRunning.toggle()
                                            soundManager.playSound()
                                        } label: {
                                            Image("Image 1")
                                                .resizable()
                                                .frame(width: 500, height: 500)
                                        }
                                    }
                                    Text("This page helps you to match the CPR tempo")
                                        .font(.system(size: 22, weight:.bold))
                                        .frame(alignment: .center)
                                        .frame(width: 700)
                                        .foregroundColor(.white)
                            
                                    Text("100 BPM")
                                        .font(.system(size: 22, weight:.bold))
                                        .frame(width: 450)
                                        .foregroundColor(.white)
                                }
                                .tag(3)
                                .onDisappear{
                                    isPlaying = false
                                    soundManager.stopAll()
                                }

                            }
                            .tabViewStyle(PageTabViewStyle())
                        .frame(width: 750, height: 850)
                            Spacer()
                        }
                    }
            }
        }
        .navigationViewStyle(StackNavigationViewStyle())
        }
    }
        
        struct CprPage_Previews: PreviewProvider {
            static var previews: some View {
                CprPage()
            }
        }

